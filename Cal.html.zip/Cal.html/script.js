let currentInput = '';
let previousInput = '';
let operator = '';

function appendNumber(number) {
  if (number === '.' && currentInput.includes('.')) return;
  currentInput = currentInput.toString() + number.toString();
  updateDisplay();
}

function appendOperator(op) {
  if (currentInput === '') return;
  if (previousInput !== '') {
    calculate();
  }
  operator = op;
  previousInput = currentInput;
  currentInput = '';
}

function calculate() {
  let result;
  const prev = parseFloat(previousInput);
  const current = parseFloat(currentInput);
  if (isNaN(prev) || isNaN(current)) return;

  switch (operator) {
    case '+':
      result = prev + current;
      break;
    case '-':
      result = prev - current;
      break;
    case '*':
      result = prev * current;
      break;
    case '/':
      if (current === 0) {
        alert("Division by zero is not allowed.");
        return;
      }
      result = prev / current;
      break;
    case 'power':
      result = Math.pow(prev, current);
      break;
    default:
      return;
  }

  currentInput = result.toString();
  operator = '';
  previousInput = '';
  updateDisplay();
}

function clearDisplay() {
  currentInput = '';
  previousInput = '';
  operator = '';
  updateDisplay();
}

function deleteLast() {
  currentInput = currentInput.toString().slice(0, -1);
  updateDisplay();
}

function updateDisplay() {
  const display = document.getElementById('display');
  display.innerText = currentInput || '0';
}

// Scientific Functions
function calculateSquareRoot() {
  currentInput = Math.sqrt(parseFloat(currentInput)).toString();
  updateDisplay();
}

function calculatePower() {
  previousInput = currentInput;
  operator = 'power';
  currentInput = '';
}

function calculateTrig(func) {
  const radians = parseFloat(currentInput) * (Math.PI / 180);
  if (func === 'sin') {
    currentInput = Math.sin(radians).toString();
  } else if (func === 'cos') {
    currentInput = Math.cos(radians).toString();
  } else if (func === 'tan') {
    currentInput = Math.tan(radians).toString();
  }
  updateDisplay();
}

function calculateLog() {
  currentInput = Math.log10(parseFloat(currentInput)).toString();
  updateDisplay();
}

function calculateExp() {
  currentInput = Math.exp(parseFloat(currentInput)).toString();
  updateDisplay();
}

function calculatePi() {
  currentInput = Math.PI.toString();
  updateDisplay();
}
